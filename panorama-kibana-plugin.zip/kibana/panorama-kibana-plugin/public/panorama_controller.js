

import {getVisualizeLoader} from 'ui/visualize/loader';
import 'ui/visualize';
import {VisProvider} from 'ui/vis';

const app = require('ui/modules').get('apps/kibana_sample_plugin', []);


