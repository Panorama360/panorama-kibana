export const PanoramaConstants = {
    LANDING_PAGE_PATH: '/panorama#'
};